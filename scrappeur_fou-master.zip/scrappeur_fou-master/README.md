3 scrapping exercices

1. trader.rb

To aggregate the names and market prices of cryptocurrencies.

2. mairie.rb

To aggregate the cities and their email addresses for the department of Val-d'Oise.

3. deputes.rb

To aggregate the first names, last names and email addresses of the 577 french deputies.
